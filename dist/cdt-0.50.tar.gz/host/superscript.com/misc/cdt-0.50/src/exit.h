#ifndef EXIT_H
#define EXIT_H

extern void _exit();

#endif
